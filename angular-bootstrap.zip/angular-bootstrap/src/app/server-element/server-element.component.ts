import { Component, OnInit,Input,OnChanges,SimpleChanges, DoCheck, AfterContentInit, AfterContentChecked, AfterViewInit, AfterViewChecked, OnDestroy ,ViewChild, ElementRef, ContentChild} from '@angular/core';
import { ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-server-element',
  templateUrl: './server-element.component.html',
  styleUrls: ['./server-element.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ServerElementComponent implements OnInit,OnChanges,DoCheck,
                                AfterContentInit,AfterContentChecked,AfterViewInit,AfterViewChecked,OnDestroy {
  @Input() element: { type : string , name : string , content : string };
  @Input() name:string;
  @ViewChild('heading',{static:true}) header: ElementRef;
  @ContentChild('contentParagraph', {static:true}) contentParagraph:ElementRef;
  constructor() { 
    console.log('constructor called');
  }

ngOnInit() {
  console.log("ngoninit called")
  console.log('Text Content' + this.header.nativeElement.textContent);
  console.log('ParagraphContent' + this.contentParagraph.nativeElement.textContent);
  }

ngOnChanges(changes: SimpleChanges) {
    //Called before any other lifecycle hook. Use it to inject dependencies, but avoid any serious work here.
    //Add '${implements OnChanges}' to the class.
    console.log("ngOnchanges Called")
    console.log(changes)
 }
 ngDoCheck(){
   console.log('ngDocheckCalled');
 }
 ngAfterContentInit(){
   console.log('ngAfterContentInit called');
 }
 ngAfterContentChecked(){
   console.log("ngAfterContentChecked");
 }
 ngAfterViewInit(){
   console.log('ng afterviewinit called');
   console.log('Text Content' + this.header.nativeElement.textContent);
   console.log('ParagraphContent' + this.contentParagraph.nativeElement.textContent);
 }
ngAfterViewChecked(){
  console.log('ng afterviewchecked');
}
ngOnDestroy(){
  console.log("OnDestroy Called");
}
}
