import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servers',
  templateUrl: './servers.component.html',
  styleUrls: ['./servers.component.css']
})
export class ServersComponent implements OnInit {
  allowNewServer:boolean  =false;
  ServerCreationStatus="No Server was created!";
  ServerName='';
  serverCreated=false;
  servers=['Testserver','Testserver 2'];

  constructor() { 
      setTimeout(() => {
        this.allowNewServer=true;
      }, 2000);
    }
  ngOnInit() {
  }
  createServer(){
    this.serverCreated=true;
    this.servers.push(this.ServerName);
    this.ServerCreationStatus='Server Was Created! Name is ' +this.ServerName;
  }
  onUpdateServerName(event:Event){
    this.ServerName=(<HTMLInputElement>event.target).value;
  }
}
