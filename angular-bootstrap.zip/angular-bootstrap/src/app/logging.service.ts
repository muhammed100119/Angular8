export class LoggingService{
    logStatusChanged(status : string){
           console.log('A Server Status Changed , new status :' + status);
    }
}