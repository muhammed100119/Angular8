import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-bootstrap';
  accounts=[
    {
      name:'Master Account',
      status:'active'
    },
    {
      name:'TestAccount',
      status:'inactive'
    },
    {
      name:'Hidden Account',
      status:'unknown'
    }
  ];
  oddNumbers:number[]=[];
  evenNumbers:number[]=[];
  serverElements=[{type:'blueprint',name:'TestServer', content:'Just A Test'}];
  onServerAdded(serverData: {serverName: string , serverContent: string}){
      this.serverElements.push({
      type:'server',
      name:serverData.serverName,
      content:serverData.serverContent
    });
                
  }
  onBlueprintAdded(blueprintData:{serverName: string , serverContent: string}){
      this.serverElements.push({
      type:'blueprint',
      name:blueprintData.serverName,
      content:blueprintData.serverContent
    }); 
  }   
  OnChangeFirst(){
    this.serverElements[0].name="Changed";
  }
  OnDestroyFirst(){
    this.serverElements.splice(0,1);
  }
 onIntervalFired(firedNumber:number){
   if(firedNumber%2 ===0){
      this.evenNumbers.push(firedNumber);
   }
    else{
      this.oddNumbers.push(firedNumber);
    }
   }
   //console.log(firedNumber)
   onAccountAdded(newAccount: {name: string,status:string}){
     this.accounts.push(newAccount);
   }
   onStatusChanged(updateInfo : { id : number, newStatus : string}){
      this.accounts[updateInfo.id].status=updateInfo.newStatus;   
                                                            
   }
 }


