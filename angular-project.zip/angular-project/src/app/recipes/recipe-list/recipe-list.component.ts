import { Component, OnInit,Output,EventEmitter } from '@angular/core';
import { Recipe } from '../recipe.model';

@Component({
  selector: 'app-recipe-list',
  templateUrl: './recipe-list.component.html',
  styleUrls: ['./recipe-list.component.css']
})
export class RecipeListComponent implements OnInit {
  @Output() recipeWasSelected= new EventEmitter<Recipe>();
  recipes: Recipe[]= [
    
    new Recipe('test recipe 000','this is very tasty','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcREZlxjqJOVGlwIVpb5ufYC_tp1rpxFPbI_wnolk8L1Mgf5Jcys'),
    new Recipe('test recipe 111','this is very crispy','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwVRJ4NU-d3ietCa1Sy6_Gs_3fP3wzBa26Z9_SmOvaHhpFD_yP'),
    new Recipe('test recipe 222','this is very spicy','https://cdn.pixabay.com/photo/2019/05/18/10/24/pizza-4211599_960_720.jpg'),
    new Recipe('test recipe 333','this is very bitter','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjX0gzy6J64UzvNM1yDLB7JZO-XxZ4BnAuIskrBk0g0BF7EbRGrQ'),
    new Recipe('test recipe 444','this is very funny','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTP5OgmH90y2eCREWTRkAFGFp-wfA2Yr9_yYmibw4jILn62_LSJ7Q')
  ];
  constructor() { }

  ngOnInit() {
  }
onRecipeSelected(recipe:Recipe){
  this.recipeWasSelected.emit(recipe);

}
}
